var r3dz3r = {
    image: ["fika",
        "rai",
        "red",
        "strawberry-cat",
        "sunflow",
        "sunflow-cat"],
    name: ["Fika",
        "Rai",
        "Red Flories",
        "Strawberry cat",
        "Sunflow",
        "Catflow"],
    artistName: "R3DZ3R",
    monitor: "@R3DZ3R_florie"
}
var changed = {
    image: ["cerberus",
        "flower-transfur",
        "hypno-bot",
        "light-latex",
        "pups",
        "tiger-shark"],
    name: ["Cerberus",
        "Flower transfur",
        "Hypno bot",
        "Light latex",
        "Dark Latex Pups",
        "Tiger Shark"],
    artistName: "Changed",
    monitor: "Changed Transfur"
}